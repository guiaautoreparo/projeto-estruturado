import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, MapPin, Star, Phone } from 'lucide-react';

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [oficinas, setOficinas] = useState([]);
  const [servicos, setServicos] = useState([]);

  useEffect(() => {
    // Buscar oficinas em destaque
    fetchOficinas();
    // Buscar serviços disponíveis
    fetchServicos();
  }, []);

  const fetchOficinas = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/oficinas`);
      const data = await response.json();
      setOficinas(data.slice(0, 6)); // Mostrar apenas as 6 primeiras
    } catch (error) {
      console.error('Erro ao buscar oficinas:', error);
      // Dados de exemplo para desenvolvimento
      setOficinas([
        { id: 1, nome: 'Auto Center Silva', endereco: 'São Paulo, SP', telefone: '(11) 99999-9999' },
        { id: 2, nome: 'Oficina do João', endereco: 'Rio de Janeiro, RJ', telefone: '(21) 88888-8888' },
        { id: 3, nome: 'Mecânica Express', endereco: 'Belo Horizonte, MG', telefone: '(31) 77777-7777' }
      ]);
    }
  };

  const fetchServicos = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/servicos`);
      const data = await response.json();
      setServicos(data);
    } catch (error) {
      console.error('Erro ao buscar serviços:', error);
      // Dados de exemplo para desenvolvimento
      setServicos([
        { id: 1, nome: 'Guincho 24h', descricao: 'Atendimento emergencial', ativo: true },
        { id: 2, nome: 'Chaveiro Automotivo', descricao: 'Cópia e abertura de portas', ativo: true },
        { id: 3, nome: 'Estética Automotiva', descricao: 'Polimento, Insulfilm', ativo: true },
        { id: 4, nome: 'Seguro Veicular', descricao: 'Cotação personalizada', ativo: true }
      ]);
    }
  };

  const handleSearch = () => {
    // Implementar lógica de busca
    console.log('Buscando por:', searchTerm);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-blue-600">Guia Auto Reparo</h1>
            <nav className="hidden md:flex space-x-6">
              <Link to="/" className="text-gray-600 hover:text-blue-600">Início</Link>
              <Link to="/oficinas" className="text-gray-600 hover:text-blue-600">Oficinas</Link>
              <Link to="/servicos" className="text-gray-600 hover:text-blue-600">Serviços</Link>
              <Link to="/contato" className="text-gray-600 hover:text-blue-600">Contato</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Encontre a <span className="text-blue-600">melhor oficina</span> para seu veículo
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Conectamos você com oficinas confiáveis na região Sudeste
          </p>
          
          {/* Search Bar */}
          <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Digite sua cidade ou CEP"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>
            <Button onClick={handleSearch} size="lg" className="h-12 px-8">
              <Search className="mr-2 h-5 w-5" />
              Buscar Oficinas
            </Button>
          </div>
        </div>
      </section>

      {/* Oficinas em Destaque */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">Oficinas Parceiras em Destaque</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {oficinas.map((oficina) => (
              <Card key={oficina.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {oficina.nome}
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-sm text-gray-600">4.8</span>
                    </div>
                  </CardTitle>
                  <CardDescription className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {oficina.endereco}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-1" />
                      {oficina.telefone}
                    </div>
                    <Link to={`/oficina/${oficina.id}`}>
                      <Button variant="outline" size="sm">Ver Detalhes</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Outros Serviços */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">Outros Serviços Disponíveis</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {servicos.map((servico) => (
              <Card key={servico.id} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{servico.nome}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">{servico.descricao}</CardDescription>
                  <Button variant="outline" size="sm">Saiba Mais</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h4 className="text-2xl font-bold mb-4">Guia Auto Reparo</h4>
          <p className="text-gray-400 mb-6">Conectando você com as melhores oficinas da região Sudeste</p>
          <div className="flex justify-center space-x-6">
            <Link to="/sobre" className="text-gray-400 hover:text-white">Sobre</Link>
            <Link to="/contato" className="text-gray-400 hover:text-white">Contato</Link>
            <Link to="/privacidade" className="text-gray-400 hover:text-white">Privacidade</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}


