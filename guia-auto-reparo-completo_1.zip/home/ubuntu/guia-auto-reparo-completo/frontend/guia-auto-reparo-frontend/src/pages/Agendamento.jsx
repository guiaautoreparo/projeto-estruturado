import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, User, Phone, Mail, Car } from 'lucide-react';

export default function Agendamento() {
  const { oficinaId } = useParams();
  const navigate = useNavigate();
  const [oficina, setOficina] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    email: '',
    data_agendamento: '',
    hora_agendamento: '',
    servico_solicitado: '',
    observacoes: ''
  });

  useEffect(() => {
    if (oficinaId) {
      fetchOficina();
    }
  }, [oficinaId]);

  const fetchOficina = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/oficinas/${oficinaId}`);
      const data = await response.json();
      setOficina(data);
    } catch (error) {
      console.error('Erro ao buscar oficina:', error);
      // Dados de exemplo para desenvolvimento
      setOficina({
        id: oficinaId,
        nome: 'Auto Center Silva',
        endereco: 'São Paulo, SP'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/agendamentos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          oficina_id: oficinaId,
          usuario_id: 1 // Em um sistema real, isso viria da autenticação
        }),
      });

      if (response.ok) {
        alert('Agendamento realizado com sucesso!');
        navigate('/');
      } else {
        alert('Erro ao realizar agendamento. Tente novamente.');
      }
    } catch (error) {
      console.error('Erro ao enviar agendamento:', error);
      alert('Erro ao realizar agendamento. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const horariosDisponiveis = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30'
  ];

  const servicosDisponiveis = [
    'Troca de óleo',
    'Alinhamento e balanceamento',
    'Revisão geral',
    'Freios',
    'Suspensão',
    'Ar condicionado',
    'Motor',
    'Elétrica',
    'Outros'
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-2xl font-bold text-blue-600">Guia Auto Reparo</Link>
            <nav className="hidden md:flex space-x-6">
              <Link to="/" className="text-gray-600 hover:text-blue-600">Início</Link>
              <Link to="/oficinas" className="text-gray-600 hover:text-blue-600">Oficinas</Link>
              <Link to="/servicos" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li><Link to="/" className="hover:text-blue-600">Início</Link></li>
            <li>/</li>
            {oficina && (
              <>
                <li><Link to={`/oficina/${oficina.id}`} className="hover:text-blue-600">{oficina.nome}</Link></li>
                <li>/</li>
              </>
            )}
            <li className="text-gray-900">Agendamento</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário de Agendamento */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Calendar className="h-6 w-6 mr-2" />
                  Agendar Serviço
                </CardTitle>
                <CardDescription>
                  Preencha os dados abaixo para agendar seu atendimento
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Dados Pessoais */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center">
                      <User className="h-5 w-5 mr-2" />
                      Dados Pessoais
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="nome">Nome Completo *</Label>
                        <Input
                          id="nome"
                          name="nome"
                          type="text"
                          required
                          value={formData.nome}
                          onChange={handleInputChange}
                          placeholder="Seu nome completo"
                        />
                      </div>
                      <div>
                        <Label htmlFor="telefone">Telefone *</Label>
                        <Input
                          id="telefone"
                          name="telefone"
                          type="tel"
                          required
                          value={formData.telefone}
                          onChange={handleInputChange}
                          placeholder="(11) 99999-9999"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  {/* Data e Horário */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Clock className="h-5 w-5 mr-2" />
                      Data e Horário
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="data_agendamento">Data *</Label>
                        <Input
                          id="data_agendamento"
                          name="data_agendamento"
                          type="date"
                          required
                          value={formData.data_agendamento}
                          onChange={handleInputChange}
                          min={new Date().toISOString().split('T')[0]}
                        />
                      </div>
                      <div>
                        <Label htmlFor="hora_agendamento">Horário *</Label>
                        <Select onValueChange={(value) => handleSelectChange('hora_agendamento', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o horário" />
                          </SelectTrigger>
                          <SelectContent>
                            {horariosDisponiveis.map((horario) => (
                              <SelectItem key={horario} value={horario}>
                                {horario}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Serviço */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Car className="h-5 w-5 mr-2" />
                      Serviço Solicitado
                    </h3>
                    
                    <div>
                      <Label htmlFor="servico_solicitado">Tipo de Serviço *</Label>
                      <Select onValueChange={(value) => handleSelectChange('servico_solicitado', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o serviço" />
                        </SelectTrigger>
                        <SelectContent>
                          {servicosDisponiveis.map((servico) => (
                            <SelectItem key={servico} value={servico}>
                              {servico}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="observacoes">Observações</Label>
                      <Textarea
                        id="observacoes"
                        name="observacoes"
                        value={formData.observacoes}
                        onChange={handleInputChange}
                        placeholder="Descreva detalhes sobre o problema ou serviço necessário..."
                        rows={4}
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full" size="lg" disabled={loading}>
                    {loading ? 'Agendando...' : 'Confirmar Agendamento'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Resumo da Oficina */}
          <div>
            {oficina && (
              <Card>
                <CardHeader>
                  <CardTitle>Resumo do Agendamento</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold">Oficina</h4>
                    <p className="text-gray-600">{oficina.nome}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Endereço</h4>
                    <p className="text-gray-600">{oficina.endereco}</p>
                  </div>
                  {formData.data_agendamento && (
                    <div>
                      <h4 className="font-semibold">Data</h4>
                      <p className="text-gray-600">
                        {new Date(formData.data_agendamento).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  )}
                  {formData.hora_agendamento && (
                    <div>
                      <h4 className="font-semibold">Horário</h4>
                      <p className="text-gray-600">{formData.hora_agendamento}</p>
                    </div>
                  )}
                  {formData.servico_solicitado && (
                    <div>
                      <h4 className="font-semibold">Serviço</h4>
                      <p className="text-gray-600">{formData.servico_solicitado}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


