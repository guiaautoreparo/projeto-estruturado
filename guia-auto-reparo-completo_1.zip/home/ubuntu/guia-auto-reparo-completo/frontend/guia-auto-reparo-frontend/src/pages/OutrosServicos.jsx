import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Truck, Key, Sparkles, Shield, Phone, Search, MapPin } from 'lucide-react';

export default function OutrosServicos() {
  const [servicos, setServicos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredServicos, setFilteredServicos] = useState([]);

  useEffect(() => {
    fetchServicos();
  }, []);

  useEffect(() => {
    // Filtrar serviços baseado no termo de busca
    const filtered = servicos.filter(servico =>
      servico.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      servico.descricao.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredServicos(filtered);
  }, [servicos, searchTerm]);

  const fetchServicos = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/servicos`);
      const data = await response.json();
      setServicos(data);
    } catch (error) {
      console.error('Erro ao buscar serviços:', error);
      // Dados de exemplo para desenvolvimento
      setServicos([
        {
          id: 1,
          nome: 'Guincho 24h',
          descricao: 'Atendimento emergencial 24 horas para reboque e socorro mecânico em toda região Sudeste',
          telefone: '(11) 99999-0001',
          whatsapp: '(11) 99999-0001',
          email: 'contato@guincho24h.com.br',
          cidade: 'São Paulo, SP',
          categoria: 'emergencia',
          ativo: true
        },
        {
          id: 2,
          nome: 'Chaveiro Automotivo',
          descricao: 'Cópia de chaves, abertura de portas, programação de chaves com chip e controles remotos',
          telefone: '(11) 99999-0002',
          whatsapp: '(11) 99999-0002',
          email: 'contato@chaveiroauto.com.br',
          cidade: 'Rio de Janeiro, RJ',
          categoria: 'chaveiro',
          ativo: true
        },
        {
          id: 3,
          nome: 'Estética Automotiva Premium',
          descricao: 'Polimento, enceramento, insulfilm, lavagem detalhada e proteção de pintura',
          telefone: '(31) 99999-0003',
          whatsapp: '(31) 99999-0003',
          email: 'contato@esteticaauto.com.br',
          cidade: 'Belo Horizonte, MG',
          categoria: 'estetica',
          ativo: true
        },
        {
          id: 4,
          nome: 'Seguro Veicular Total',
          descricao: 'Cotação personalizada de seguros para veículos nacionais e importados com as melhores seguradoras',
          telefone: '(21) 99999-0004',
          whatsapp: '(21) 99999-0004',
          email: 'contato@seguroveicular.com.br',
          cidade: 'Rio de Janeiro, RJ',
          categoria: 'seguro',
          ativo: true
        },
        {
          id: 5,
          nome: 'Despachante Veicular',
          descricao: 'Documentação veicular, transferência, licenciamento, IPVA e multas',
          telefone: '(11) 99999-0005',
          whatsapp: '(11) 99999-0005',
          email: 'contato@despachante.com.br',
          cidade: 'São Paulo, SP',
          categoria: 'documentacao',
          ativo: true
        },
        {
          id: 6,
          nome: 'Vistoria Veicular',
          descricao: 'Vistoria técnica para transferência, financiamento e seguros',
          telefone: '(19) 99999-0006',
          whatsapp: '(19) 99999-0006',
          email: 'contato@vistoria.com.br',
          cidade: 'Campinas, SP',
          categoria: 'vistoria',
          ativo: true
        }
      ]);
    }
  };

  const getServiceIcon = (categoria) => {
    switch (categoria) {
      case 'emergencia':
        return <Truck className="h-8 w-8 text-red-500" />;
      case 'chaveiro':
        return <Key className="h-8 w-8 text-yellow-500" />;
      case 'estetica':
        return <Sparkles className="h-8 w-8 text-blue-500" />;
      case 'seguro':
        return <Shield className="h-8 w-8 text-green-500" />;
      default:
        return <Phone className="h-8 w-8 text-gray-500" />;
    }
  };

  const getCategoryColor = (categoria) => {
    switch (categoria) {
      case 'emergencia':
        return 'bg-red-100 text-red-800';
      case 'chaveiro':
        return 'bg-yellow-100 text-yellow-800';
      case 'estetica':
        return 'bg-blue-100 text-blue-800';
      case 'seguro':
        return 'bg-green-100 text-green-800';
      case 'documentacao':
        return 'bg-purple-100 text-purple-800';
      case 'vistoria':
        return 'bg-indigo-100 text-indigo-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryName = (categoria) => {
    switch (categoria) {
      case 'emergencia':
        return 'Emergência';
      case 'chaveiro':
        return 'Chaveiro';
      case 'estetica':
        return 'Estética';
      case 'seguro':
        return 'Seguro';
      case 'documentacao':
        return 'Documentação';
      case 'vistoria':
        return 'Vistoria';
      default:
        return 'Outros';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-2xl font-bold text-blue-600">Guia Auto Reparo</Link>
            <nav className="hidden md:flex space-x-6">
              <Link to="/" className="text-gray-600 hover:text-blue-600">Início</Link>
              <Link to="/oficinas" className="text-gray-600 hover:text-blue-600">Oficinas</Link>
              <Link to="/servicos" className="text-blue-600 font-medium">Serviços</Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li><Link to="/" className="hover:text-blue-600">Início</Link></li>
            <li>/</li>
            <li className="text-gray-900">Outros Serviços</li>
          </ol>
        </nav>

        {/* Header da Página */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Outros Serviços Automotivos</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Encontre serviços especializados para seu veículo além das oficinas tradicionais
          </p>
        </div>

        {/* Barra de Busca */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar serviços..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Grid de Serviços */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServicos.map((servico) => (
            <Card key={servico.id} className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    {getServiceIcon(servico.categoria)}
                    <div>
                      <CardTitle className="text-lg">{servico.nome}</CardTitle>
                      <div className="flex items-center mt-1">
                        <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                        <span className="text-sm text-gray-600">{servico.cidade}</span>
                      </div>
                    </div>
                  </div>
                  <Badge className={getCategoryColor(servico.categoria)}>
                    {getCategoryName(servico.categoria)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <CardDescription className="text-gray-700 leading-relaxed">
                  {servico.descricao}
                </CardDescription>
                
                <div className="space-y-2">
                  {servico.telefone && (
                    <div className="flex items-center text-sm">
                      <Phone className="h-4 w-4 text-gray-400 mr-2" />
                      <span>{servico.telefone}</span>
                    </div>
                  )}
                  {servico.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <span className="truncate">{servico.email}</span>
                    </div>
                  )}
                </div>

                <div className="flex space-x-2 pt-2">
                  <Button className="flex-1" size="sm">
                    <Phone className="h-4 w-4 mr-1" />
                    Ligar
                  </Button>
                  {servico.whatsapp && (
                    <Button variant="outline" className="flex-1" size="sm">
                      WhatsApp
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredServicos.length === 0 && searchTerm && (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">
              Nenhum serviço encontrado para "{searchTerm}"
            </p>
            <Button 
              variant="outline" 
              onClick={() => setSearchTerm('')}
              className="mt-4"
            >
              Limpar busca
            </Button>
          </div>
        )}

        {/* Call to Action */}
        <div className="mt-16 bg-blue-600 rounded-lg p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Não encontrou o que procura?</h3>
          <p className="text-blue-100 mb-6">
            Entre em contato conosco e ajudaremos você a encontrar o serviço ideal para seu veículo
          </p>
          <Button variant="secondary" size="lg">
            Falar Conosco
          </Button>
        </div>
      </div>
    </div>
  );
}


