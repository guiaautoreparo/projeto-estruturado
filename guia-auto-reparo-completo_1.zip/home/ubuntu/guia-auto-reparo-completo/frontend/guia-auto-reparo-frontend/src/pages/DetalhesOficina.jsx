import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Phone, Mail, Clock, Star, Calendar } from 'lucide-react';

export default function DetalhesOficina() {
  const { id } = useParams();
  const [oficina, setOficina] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOficina();
  }, [id]);

  const fetchOficina = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3000'}/api/oficinas/${id}`);
      const data = await response.json();
      setOficina(data);
    } catch (error) {
      console.error('Erro ao buscar oficina:', error);
      // Dados de exemplo para desenvolvimento
      setOficina({
        id: id,
        nome: 'Auto Center Silva',
        endereco: 'Rua das Flores, 123 - São Paulo, SP',
        telefone: '(11) 99999-9999',
        email: 'contato@autocentrosilva.com.br',
        descricao: 'Oficina especializada em manutenção preventiva e corretiva de veículos nacionais e importados. Atendemos com qualidade há mais de 20 anos.',
        servicos_oferecidos: 'Troca de óleo, Alinhamento, Balanceamento, Freios, Suspensão, Motor, Ar condicionado',
        horario_funcionamento: 'Segunda a Sexta: 8h às 18h | Sábado: 8h às 12h',
        avaliacao: 4.8,
        total_avaliacoes: 127
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando informações da oficina...</p>
        </div>
      </div>
    );
  }

  if (!oficina) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Oficina não encontrada</h2>
          <Link to="/">
            <Button>Voltar ao Início</Button>
          </Link>
        </div>
      </div>
    );
  }

  const servicos = oficina.servicos_oferecidos ? oficina.servicos_oferecidos.split(', ') : [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-2xl font-bold text-blue-600">Guia Auto Reparo</Link>
            <nav className="hidden md:flex space-x-6">
              <Link to="/" className="text-gray-600 hover:text-blue-600">Início</Link>
              <Link to="/oficinas" className="text-gray-600 hover:text-blue-600">Oficinas</Link>
              <Link to="/servicos" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li><Link to="/" className="hover:text-blue-600">Início</Link></li>
            <li>/</li>
            <li><Link to="/oficinas" className="hover:text-blue-600">Oficinas</Link></li>
            <li>/</li>
            <li className="text-gray-900">{oficina.nome}</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Informações Principais */}
          <div className="lg:col-span-2 space-y-6">
            {/* Cabeçalho da Oficina */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-3xl font-bold">{oficina.nome}</CardTitle>
                    <CardDescription className="flex items-center mt-2">
                      <MapPin className="h-4 w-4 mr-1" />
                      {oficina.endereco}
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-400 fill-current" />
                      <span className="ml-1 text-lg font-semibold">{oficina.avaliacao}</span>
                    </div>
                    <p className="text-sm text-gray-600">{oficina.total_avaliacoes} avaliações</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">{oficina.descricao}</p>
              </CardContent>
            </Card>

            {/* Serviços Oferecidos */}
            <Card>
              <CardHeader>
                <CardTitle>Serviços Oferecidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {servicos.map((servico, index) => (
                    <Badge key={index} variant="secondary" className="text-sm">
                      {servico.trim()}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Horário de Funcionamento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Horário de Funcionamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{oficina.horario_funcionamento}</p>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Informações de Contato e Agendamento */}
          <div className="space-y-6">
            {/* Contato */}
            <Card>
              <CardHeader>
                <CardTitle>Informações de Contato</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="font-medium">{oficina.telefone}</p>
                    <p className="text-sm text-gray-600">Telefone</p>
                  </div>
                </div>
                {oficina.email && (
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="font-medium">{oficina.email}</p>
                      <p className="text-sm text-gray-600">E-mail</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Agendamento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Agendar Serviço
                </CardTitle>
                <CardDescription>
                  Agende seu atendimento de forma rápida e prática
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link to={`/agendamento/${oficina.id}`} className="block">
                  <Button className="w-full" size="lg">
                    <Calendar className="h-5 w-5 mr-2" />
                    Agendar Agora
                  </Button>
                </Link>
                <div className="text-center">
                  <p className="text-sm text-gray-600">ou</p>
                  <Button variant="outline" className="w-full mt-2">
                    <Phone className="h-4 w-4 mr-2" />
                    Ligar Agora
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Localização */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Localização
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-200 h-48 rounded-lg flex items-center justify-center">
                  <p className="text-gray-600">Mapa da localização</p>
                </div>
                <p className="text-sm text-gray-600 mt-2">{oficina.endereco}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

