import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import DetalhesOficina from './pages/DetalhesOficina';
import Agendamento from './pages/Agendamento';
import OutrosServicos from './pages/OutrosServicos';
// Importe outros componentes de página conforme necessário

function App() {
  return (
    <Router>
      <div className="App">
        {/* Navbar ou outros componentes de layout podem ir aqui */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/oficina/:id" element={<DetalhesOficina />} />
          <Route path="/agendamento" element={<Agendamento />} />
          <Route path="/servicos" element={<OutrosServicos />} />
          {/* Adicione outras rotas aqui */}
        </Routes>
        {/* Footer ou outros componentes de layout podem ir aqui */}
      </div>
    </Router>
  );
}

export default App;


