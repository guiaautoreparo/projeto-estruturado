require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();

// Configuração do CORS para produção
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3001", // Permitir apenas o frontend
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true,
}));

app.use(express.json());

// Importar a configuração do banco de dados
const db = require("./config/db");

// Rotas
app.use("/api/usuarios", require("./routes/usuarios"));
app.use("/api/oficinas", require("./routes/oficinas"));
app.use("/api/agendamentos", require("./routes/agendamentos"));
app.use("/api/servicos", require("./routes/servicos"));
app.use("/api/admin", require("./routes/admin"));

// Rota de teste de conexão com o banco de dados
app.get("/api/test-db", async (req, res) => {
  try {
    await db.getConnection();
    res.status(200).json({ message: "Conexão com o banco de dados bem-sucedida!" });
  } catch (error) {
    console.error("Erro na conexão com o banco de dados:", error);
    res.status(500).json({ message: "Erro na conexão com o banco de dados", error: error.message });
  }
});

const PORT = process.env.PORT || 3000; // Usar porta 3000 como padrão, conforme o PDF
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT} (ambiente: ${process.env.NODE_ENV || 'development'})`));


