const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Rota de cadastro de usuário
router.post("/register", async (req, res) => {
  const { nome, telefone, whatsapp, email, carro, password } = req.body;
  try {
    // Verificar se o email já existe
    const [existingUser] = await db.execute("SELECT id FROM usuarios WHERE email = ?", [email]);
    if (existingUser.length > 0) {
      return res.status(409).json({ message: "Email já cadastrado." });
    }

    // Inserir novo usuário (password deve ser hashed em um ambiente real)
    const [result] = await db.execute(
      "INSERT INTO usuarios (nome, telefone, whatsapp, email, carro, password) VALUES (?, ?, ?, ?, ?, ?)",
      [nome, telefone, whatsapp, email, carro, password] // Em produção, use bcrypt para hash de senha
    );
    res.status(201).json({ message: "Usuário cadastrado com sucesso!", userId: result.insertId });
  } catch (error) {
    console.error("Erro ao cadastrar usuário:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota de login de usuário (simplificada)
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const [users] = await db.execute("SELECT * FROM usuarios WHERE email = ? AND password = ?", [email, password]);
    if (users.length === 0) {
      return res.status(401).json({ message: "Email ou senha inválidos." });
    }
    const user = users[0];
    // Em produção, gerar um token JWT aqui
    res.status(200).json({ message: "Login bem-sucedido!", user: { id: user.id, nome: user.nome, email: user.email } });
  } catch (error) {
    console.error("Erro ao fazer login:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para obter todos os usuários (apenas para admin, em um ambiente real)
router.get("/", async (req, res) => {
  try {
    const [users] = await db.execute("SELECT id, nome, telefone, whatsapp, email, carro FROM usuarios");
    res.status(200).json(users);
  } catch (error) {
    console.error("Erro ao buscar usuários:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para obter usuário por ID
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const [users] = await db.execute("SELECT id, nome, telefone, whatsapp, email, carro FROM usuarios WHERE id = ?", [id]);
    if (users.length === 0) {
      return res.status(404).json({ message: "Usuário não encontrado." });
    }
    res.status(200).json(users[0]);
  } catch (error) {
    console.error("Erro ao buscar usuário por ID:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para atualizar usuário
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { nome, telefone, whatsapp, email, carro } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE usuarios SET nome = ?, telefone = ?, whatsapp = ?, email = ?, carro = ? WHERE id = ?",
      [nome, telefone, whatsapp, email, carro, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Usuário não encontrado." });
    }
    res.status(200).json({ message: "Usuário atualizado com sucesso!" });
  } catch (error) {
    console.error("Erro ao atualizar usuário:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para soft delete de usuário (marcar como inativo)
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    // Assumindo que a tabela de usuários tem uma coluna 'ativo' ou 'deleted_at'
    // Para este exemplo, vamos apenas 


marcar como deletado simbolicamente.
    // Em um cenário real, você pode ter uma coluna `is_active` ou `deleted_at`.
    // Por simplicidade, aqui vamos apenas retornar uma mensagem de sucesso.
    res.status(200).json({ message: "Usuário marcado para exclusão (soft delete)." });
  } catch (error) {
    console.error("Erro ao deletar usuário:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

module.exports = router;


