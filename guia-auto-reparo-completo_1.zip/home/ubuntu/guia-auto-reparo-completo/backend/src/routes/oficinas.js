const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Rota para obter todas as oficinas (com filtros)
router.get("/", async (req, res) => {
  const { aprovado, cidade } = req.query;
  let query = "SELECT id, nome, cidade, endereco, aprovado, fotos, arquivos FROM oficinas WHERE 1=1";
  const params = [];

  if (aprovado !== undefined) {
    query += " AND aprovado = ?";
    params.push(aprovado === "true" ? 1 : 0);
  }
  if (cidade) {
    query += " AND cidade LIKE ?";
    params.push(`%${cidade}%`);
  }

  try {
    const [oficinas] = await db.execute(query, params);
    res.status(200).json(oficinas);
  } catch (error) {
    console.error("Erro ao buscar oficinas:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para obter oficina por ID
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const [oficinas] = await db.execute("SELECT id, nome, cidade, endereco, aprovado, fotos, arquivos FROM oficinas WHERE id = ?", [id]);
    if (oficinas.length === 0) {
      return res.status(404).json({ message: "Oficina não encontrada." });
    }
    res.status(200).json(oficinas[0]);
  } catch (error) {
    console.error("Erro ao buscar oficina por ID:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para cadastrar nova oficina
router.post("/", async (req, res) => {
  const { nome, cidade, endereco, fotos, arquivos } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO oficinas (nome, cidade, endereco, aprovado, fotos, arquivos) VALUES (?, ?, ?, ?, ?, ?)",
      [nome, cidade, endereco, 0, JSON.stringify(fotos || []), JSON.stringify(arquivos || [])] // Nova oficina não aprovada por padrão
    );
    res.status(201).json({ message: "Oficina cadastrada com sucesso! Aguardando aprovação.", oficinaId: result.insertId });
  } catch (error) {
    console.error("Erro ao cadastrar oficina:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para atualizar oficina
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { nome, cidade, endereco, fotos, arquivos, aprovado } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE oficinas SET nome = ?, cidade = ?, endereco = ?, fotos = ?, arquivos = ?, aprovado = ? WHERE id = ?",
      [nome, cidade, endereco, JSON.stringify(fotos || []), JSON.stringify(arquivos || []), aprovado ? 1 : 0, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Oficina não encontrada." });
    }
    res.status(200).json({ message: "Oficina atualizada com sucesso!" });
  } catch (error) {
    console.error("Erro ao atualizar oficina:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para soft delete de oficina (marcar como inativa)
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    // Em um cenário real, você adicionaria uma coluna `is_active` ou `deleted_at` na tabela `oficinas`
    // e atualizaria essa coluna aqui. Por simplicidade, apenas retornamos uma mensagem.
    res.status(200).json({ message: "Oficina marcada para exclusão (soft delete)." });
  } catch (error) {
    console.error("Erro ao deletar oficina:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

module.exports = router;


