const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET - Buscar todos os agendamentos
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT a.*, u.nome as usuario_nome, o.nome as oficina_nome 
      FROM agendamentos a 
      LEFT JOIN usuarios u ON a.usuario_id = u.id 
      LEFT JOIN oficinas o ON a.oficina_id = o.id 
      WHERE a.ativo = TRUE
      ORDER BY a.data_agendamento DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error('Erro ao buscar agendamentos:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET - Buscar agendamento por ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT a.*, u.nome as usuario_nome, o.nome as oficina_nome 
      FROM agendamentos a 
      LEFT JOIN usuarios u ON a.usuario_id = u.id 
      LEFT JOIN oficinas o ON a.oficina_id = o.id 
      WHERE a.id = ? AND a.ativo = TRUE
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Agendamento não encontrado' });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error('Erro ao buscar agendamento:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// POST - Criar novo agendamento
router.post('/', async (req, res) => {
  try {
    const { usuario_id, oficina_id, data_agendamento, hora_agendamento, servico_solicitado, observacoes } = req.body;
    
    const [result] = await db.execute(
      'INSERT INTO agendamentos (usuario_id, oficina_id, data_agendamento, hora_agendamento, servico_solicitado, observacoes, status, ativo, data_criacao) VALUES (?, ?, ?, ?, ?, ?, "pendente", TRUE, NOW())',
      [usuario_id, oficina_id, data_agendamento, hora_agendamento, servico_solicitado, observacoes]
    );
    
    res.status(201).json({ id: result.insertId, message: 'Agendamento criado com sucesso' });
  } catch (err) {
    console.error('Erro ao criar agendamento:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// PUT - Atualizar agendamento
router.put('/:id', async (req, res) => {
  try {
    const { data_agendamento, hora_agendamento, servico_solicitado, observacoes, status } = req.body;
    
    const [result] = await db.execute(
      'UPDATE agendamentos SET data_agendamento = ?, hora_agendamento = ?, servico_solicitado = ?, observacoes = ?, status = ? WHERE id = ?',
      [data_agendamento, hora_agendamento, servico_solicitado, observacoes, status, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Agendamento não encontrado' });
    }
    
    res.json({ message: 'Agendamento atualizado com sucesso' });
  } catch (err) {
    console.error('Erro ao atualizar agendamento:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// DELETE - Cancelar agendamento (soft delete)
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.execute('UPDATE agendamentos SET ativo = FALSE, status = "cancelado" WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Agendamento não encontrado' });
    }
    
    res.json({ message: 'Agendamento cancelado com sucesso' });
  } catch (err) {
    console.error('Erro ao cancelar agendamento:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET - Buscar agendamentos por usuário
router.get('/usuario/:usuario_id', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT a.*, o.nome as oficina_nome 
      FROM agendamentos a 
      LEFT JOIN oficinas o ON a.oficina_id = o.id 
      WHERE a.usuario_id = ? AND a.ativo = TRUE
      ORDER BY a.data_agendamento DESC
    `, [req.params.usuario_id]);
    
    res.json(rows);
  } catch (err) {
    console.error('Erro ao buscar agendamentos do usuário:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET - Buscar agendamentos por oficina
router.get('/oficina/:oficina_id', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT a.*, u.nome as usuario_nome 
      FROM agendamentos a 
      LEFT JOIN usuarios u ON a.usuario_id = u.id 
      WHERE a.oficina_id = ? AND a.ativo = TRUE
      ORDER BY a.data_agendamento DESC
    `, [req.params.oficina_id]);
    
    res.json(rows);
  } catch (err) {
    console.error('Erro ao buscar agendamentos da oficina:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

module.exports = router;


const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Rota para obter todos os agendamentos (com filtros e joins)
router.get("/", async (req, res) => {
  const { usuario_id, oficina_id, status } = req.query;
  let query = `
    SELECT
      a.id, a.data, a.status,
      u.nome AS usuario_nome, u.email AS usuario_email,
      o.nome AS oficina_nome, o.cidade AS oficina_cidade
    FROM agendamentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN oficinas o ON a.oficina_id = o.id
    WHERE 1=1
  `;
  const params = [];

  if (usuario_id) {
    query += " AND a.usuario_id = ?";
    params.push(usuario_id);
  }
  if (oficina_id) {
    query += " AND a.oficina_id = ?";
    params.push(oficina_id);
  }
  if (status) {
    query += " AND a.status = ?";
    params.push(status);
  }

  try {
    const [agendamentos] = await db.execute(query, params);
    res.status(200).json(agendamentos);
  } catch (error) {
    console.error("Erro ao buscar agendamentos:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para obter agendamento por ID
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const [agendamentos] = await db.execute(
      `
      SELECT
        a.id, a.data, a.status,
        u.nome AS usuario_nome, u.email AS usuario_email,
        o.nome AS oficina_nome, o.cidade AS oficina_cidade
      FROM agendamentos a
      JOIN usuarios u ON a.usuario_id = u.id
      JOIN oficinas o ON a.oficina_id = o.id
      WHERE a.id = ?
      `,
      [id]
    );
    if (agendamentos.length === 0) {
      return res.status(404).json({ message: "Agendamento não encontrado." });
    }
    res.status(200).json(agendamentos[0]);
  } catch (error) {
    console.error("Erro ao buscar agendamento por ID:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para criar novo agendamento
router.post("/", async (req, res) => {
  const { usuario_id, oficina_id, data, status } = req.body;
  try {
    const [result] = await db.execute(
      "INSERT INTO agendamentos (usuario_id, oficina_id, data, status) VALUES (?, ?, ?, ?)",
      [usuario_id, oficina_id, data, status || "pendente"]
    );
    res.status(201).json({ message: "Agendamento criado com sucesso!", agendamentoId: result.insertId });
  } catch (error) {
    console.error("Erro ao criar agendamento:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para atualizar agendamento
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { usuario_id, oficina_id, data, status } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE agendamentos SET usuario_id = ?, oficina_id = ?, data = ?, status = ? WHERE id = ?",
      [usuario_id, oficina_id, data, status, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Agendamento não encontrado." });
    }
    res.status(200).json({ message: "Agendamento atualizado com sucesso!" });
  } catch (error) {
    console.error("Erro ao atualizar agendamento:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para deletar agendamento
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.execute("DELETE FROM agendamentos WHERE id = ?", [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Agendamento não encontrado." });
    }
    res.status(200).json({ message: "Agendamento deletado com sucesso!" });
  } catch (error) {
    console.error("Erro ao deletar agendamento:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

module.exports = router;


