const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Rota para dashboard com estatísticas
router.get("/dashboard", async (req, res) => {
  try {
    const [totalUsers] = await db.execute("SELECT COUNT(*) AS count FROM usuarios");
    const [totalOficinas] = await db.execute("SELECT COUNT(*) AS count FROM oficinas");
    const [totalAgendamentos] = await db.execute("SELECT COUNT(*) AS count FROM agendamentos");
    const [pendingAgendamentos] = await db.execute("SELECT COUNT(*) AS count FROM agendamentos WHERE status = 'pendente'");

    res.status(200).json({
      totalUsers: totalUsers[0].count,
      totalOficinas: totalOficinas[0].count,
      totalAgendamentos: totalAgendamentos[0].count,
      pendingAgendamentos: pendingAgendamentos[0].count,
    });
  } catch (error) {
    console.error("Erro ao buscar dados do dashboard:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para aprovar/rejeitar oficinas
router.put("/oficinas/:id/status", async (req, res) => {
  const { id } = req.params;
  const { aprovado } = req.body; // true para aprovar, false para rejeitar
  try {
    const [result] = await db.execute("UPDATE oficinas SET aprovado = ? WHERE id = ?", [aprovado ? 1 : 0, id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Oficina não encontrada." });
    }
    res.status(200).json({ message: `Oficina ${aprovado ? 'aprovada' : 'rejeitada'} com sucesso!` });
  } catch (error) {
    console.error("Erro ao atualizar status da oficina:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

// Rota para obter relatórios de agendamentos (exemplo)
router.get("/relatorios/agendamentos", async (req, res) => {
  const { status, startDate, endDate } = req.query;
  let query = `
    SELECT
      a.id, a.data, a.status,
      u.nome AS usuario_nome, u.email AS usuario_email,
      o.nome AS oficina_nome, o.cidade AS oficina_cidade
    FROM agendamentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN oficinas o ON a.oficina_id = o.id
    WHERE 1=1
  `;
  const params = [];

  if (status) {
    query += " AND a.status = ?";
    params.push(status);
  }
  if (startDate) {
    query += " AND a.data >= ?";
    params.push(startDate);
  }
  if (endDate) {
    query += " AND a.data <= ?";
    params.push(endDate);
  }

  try {
    const [reports] = await db.execute(query, params);
    res.status(200).json(reports);
  } catch (error) {
    console.error("Erro ao gerar relatório de agendamentos:", error);
    res.status(500).json({ message: "Erro interno do servidor" });
  }
});

module.exports = router;


