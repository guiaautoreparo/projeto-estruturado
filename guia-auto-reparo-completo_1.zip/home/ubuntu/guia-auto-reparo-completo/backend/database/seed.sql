
-- Dados de exemplo para o banco de dados Guia Auto Reparo

-- Inserir usuários de exemplo
INSERT INTO usuarios (nome, telefone, whatsapp, email, carro, password, is_active) VALUES
("João Silva", "11987654321", "11987654321", "joao.silva@example.com", "Ford Ka", "senha123", TRUE),
("Maria Souza", "21998765432", "21998765432", "maria.souza@example.com", "Fiat Palio", "senha456", TRUE),
("Carlos Oliveira", "31976543210", "31976543210", "carlos.o@example.com", "VW Gol", "senha789", TRUE);

-- Inserir oficinas de exemplo
INSERT INTO oficinas (nome, cidade, endereco, aprovado, fotos, arquivos, descricao, servicos_oferecidos, horario_funcionamento, avaliacao, total_avaliacoes, is_active) VALUES
("Oficina Central", "São Paulo", "Rua da Consolação, 1000", TRUE, "[]", "[]", "Oficina completa para todas as marcas e modelos.", "Troca de óleo, Freios, Suspensão, Motor", "Segunda a Sexta: 8h-18h", 4.5, 50, TRUE),
("Mecânica Rápida", "Rio de Janeiro", "Av. Atlântica, 500", TRUE, "[]", "[]", "Serviços rápidos e eficientes para o seu dia a dia.", "Troca de óleo, Pneus, Bateria", "Segunda a Sábado: 9h-17h", 4.2, 30, TRUE),
("Auto Elétrica Brasil", "Belo Horizonte", "Rua da Bahia, 200", TRUE, "[]", "[]", "Especialistas em elétrica automotiva.", "Elétrica, Injeção Eletrônica, Alternador", "Segunda a Sexta: 8h-17h", 4.8, 25, TRUE);

-- Inserir agendamentos de exemplo
INSERT INTO agendamentos (usuario_id, oficina_id, data, status) VALUES
(1, 1, "2025-07-01 10:00:00", "confirmado"),
(2, 2, "2025-07-02 14:30:00", "pendente"),
(3, 3, "2025-07-03 09:00:00", "reagendado");

-- Inserir serviços parceiros de exemplo
INSERT INTO servicos_parceiros (nome, descricao, ativo) VALUES
("Guincho 24h", "Atendimento emergencial de guincho a qualquer hora.", TRUE),
("Chaveiro Automotivo", "Serviços de chaveiro para veículos, cópia e abertura.", TRUE),
("Estética Automotiva", "Polimento, cristalização e lavagem detalhada.", TRUE);

-- Inserir avaliações de exemplo
INSERT INTO avaliacoes (usuario_id, oficina_id, nota, comentario) VALUES
(1, 1, 5.0, "Excelente serviço, muito rápido e eficiente!"),
(2, 2, 4.0, "Bom atendimento, mas demorou um pouco."),
(3, 3, 4.5, "Resolveram meu problema elétrico rapidamente.");


