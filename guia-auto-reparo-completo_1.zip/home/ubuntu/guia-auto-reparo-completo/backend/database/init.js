const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });

async function initializeDatabase() {
  const connectionConfig = {
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
  };

  const dbName = process.env.DB_NAME || "guia_auto_reparo";

  let connection;
  try {
    // Conectar ao servidor MySQL (sem especificar o banco de dados inicialmente)
    connection = await mysql.createConnection(connectionConfig);

    // Criar o banco de dados se não existir
    await connection.execute(`CREATE DATABASE IF NOT EXISTS 
```sql
${dbName}
```
`);
    console.log(`Banco de dados '${dbName}' verificado/criado com sucesso.`);

    // Conectar ao banco de dados específico
    await connection.end(); // Fechar a conexão sem banco de dados
    connectionConfig.database = dbName;
    connection = await mysql.createConnection(connectionConfig);

    // Executar o schema_completo.sql
    const schemaSql = fs.readFileSync(path.resolve(__dirname, "schema_completo.sql"), "utf8");
    const schemaStatements = schemaSql.split(";").filter(s => s.trim() !== "");
    for (const statement of schemaStatements) {
      await connection.execute(statement);
    }
    console.log("Schema do banco de dados aplicado com sucesso.");

    // Executar o seed.sql (dados de exemplo)
    const seedSql = fs.readFileSync(path.resolve(__dirname, "seed.sql"), "utf8");
    const seedStatements = seedSql.split(";").filter(s => s.trim() !== "");
    for (const statement of seedStatements) {
      await connection.execute(statement);
    }
    console.log("Dados de exemplo (seed) aplicados com sucesso.");

  } catch (error) {
    console.error("Erro ao inicializar o banco de dados:", error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

initializeDatabase();


