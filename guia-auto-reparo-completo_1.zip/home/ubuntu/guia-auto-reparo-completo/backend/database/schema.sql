
CREATE TABLE usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100),
  telefone VARCHAR(20),
  whatsapp VARCHAR(20),
  email VARCHAR(100),
  carro VARCHAR(100)
);

CREATE TABLE oficinas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100),
  cidade VARCHAR(100),
  endereco VARCHAR(150),
  aprovado BOOLEAN,
  fotos JSON,
  arquivos JSON
);

CREATE TABLE agendamentos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT,
  oficina_id INT,
  data DATETIME,
  status ENUM('pendente', 'confirmado', 'reagendado')
);

CREATE TABLE solicitacoes_alteracao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  oficina_id INT,
  dados_novos JSON,
  status ENUM('pendente', 'aprovada', 'rejeitada') DEFAULT 'pendente',
  criado_em DATETIME
);
