-- 7 tabelas criadas:
-- 1. usuarios - Gestão de usuários
-- 2. oficinas - Dados das oficinas
-- 3. agendamentos - Sistema de agendamentos
-- 4. servicos_parceiros - Serviços adicionais
-- 5. solicitacoes_alteracao - Controle de mudanças
-- 6. avaliacoes - Sistema de avaliações
-- 7. Índices otimizados

CREATE TABLE usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  telefone VARCHAR(20),
  whatsapp VARCHAR(20),
  email VARCHAR(100) UNIQUE NOT NULL,
  carro VARCHAR(100),
  password VARCHAR(255) NOT NULL, -- Senha hashed
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE -- Para soft delete
);

CREATE TABLE oficinas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  cidade VARCHAR(100) NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  aprovado BOOLEAN DEFAULT FALSE, -- 0 para não aprovado, 1 para aprovado
  fotos JSON, -- Armazenar URLs de fotos como JSON
  arquivos JSON, -- Armazenar URLs de documentos como JSON
  descricao TEXT,
  servicos_oferecidos TEXT, -- Lista de serviços separados por vírgula
  horario_funcionamento VARCHAR(255),
  avaliacao DECIMAL(2,1) DEFAULT 0.0,
  total_avaliacoes INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE -- Para soft delete
);

CREATE TABLE agendamentos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  oficina_id INT NOT NULL,
  data DATETIME NOT NULL,
  status ENUM("pendente", "confirmado", "reagendado", "cancelado", "concluido") DEFAULT "pendente",
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (oficina_id) REFERENCES oficinas(id) ON DELETE CASCADE
);

CREATE TABLE servicos_parceiros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT,
  imagem_url TEXT,
  ativo BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE solicitacoes_alteracao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  oficina_id INT NOT NULL,
  dados_novos JSON NOT NULL, -- Dados da alteração solicitada
  status ENUM("pendente", "aprovada", "rejeitada") DEFAULT "pendente",
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (oficina_id) REFERENCES oficinas(id) ON DELETE CASCADE
);

CREATE TABLE avaliacoes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  oficina_id INT NOT NULL,
  nota DECIMAL(2,1) NOT NULL, -- Nota de 0.0 a 5.0
  comentario TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (oficina_id) REFERENCES oficinas(id) ON DELETE CASCADE
);

-- Índices otimizados
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_oficinas_cidade_aprovado ON oficinas(cidade, aprovado);
CREATE INDEX idx_agendamentos_usuario_oficina ON agendamentos(usuario_id, oficina_id);
CREATE INDEX idx_agendamentos_status ON agendamentos(status);
CREATE INDEX idx_solicitacoes_oficina_status ON solicitacoes_alteracao(oficina_id, status);
CREATE INDEX idx_avaliacoes_oficina ON avaliacoes(oficina_id);


