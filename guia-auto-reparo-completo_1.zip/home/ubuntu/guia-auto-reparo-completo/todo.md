# TODO - Guia Auto Reparo

## Backend
- [x] Modificar `backend/src/server.js` (CORS, rotas, teste DB, variáveis de ambiente)
- [x] Modificar `backend/src/config/db.js` (Pool de conexões, variáveis de ambiente, tratamento de erros)
- [x] Criar `backend/src/routes/usuarios.js` (CRUD completo, login, validação)
- [x] Criar `backend/src/routes/oficinas.js` (CRUD completo, aprovação, filtros)
- [x] Criar `backend/src/routes/agendamentos.js` (CRUD completo, busca, status, joins)
- [x] Criar `backend/src/routes/admin.js` (Dashboard, aprovação, relatórios)
- [x] Modificar `backend/src/routes/servicos.js` (Conexão DB, tratamento de erros, filtros)
- [x] Criar `backend/src/.env` (Variáveis de ambiente)
- [x] Criar `backend/database/schema_completo.sql` (7 tabelas, índices)
- [x] Criar `backend/database/seed.sql` (Dados de exemplo)
- [x] Criar `backend/database/init.js` (Script de inicialização do DB)

## Frontend
- [x] Modificar `frontend/guia-auto-reparo-frontend/src/App.jsx` (React Router, rotas)
- [x] Modificar `frontend/guia-auto-reparo-frontend/src/pages/Home.jsx` (Design responsivo, busca, API, footer)
- [x] Modificar `frontend/guia-auto-reparo-frontend/src/pages/DetalhesOficina.jsx` (Detalhes, avaliações, agendamento)
- [x] Modificar `frontend/guia-auto-reparo-frontend/src/pages/Agendamento.jsx` (Formulário, validação, horários, API)
- [x] Modificar `frontend/guia-auto-reparo-frontend/src/pages/OutrosServicos.jsx` (Catálogo, busca, filtros, API)
- [x] Modificar `frontend/guia-auto-reparo-frontend/index.html` (Título)
- [x] Criar `frontend/guia-auto-reparo-frontend/.env` (Variáveis de ambiente)

## Configuração Geral
- [x] Criar `docker-compose.yml` (Containerização)
- [x] Criar `README.md` (Documentação do projeto)
- [x] Criar `.gitignore` (Arquivos a ignorar)

## Próximos Passos
- [ ] Testes Locais (Manual e Automatizado)
- [ ] Deploy em Ambiente de Testes
- [ ] Otimização de Performance
- [ ] Implementação de Autenticação (JWT)
- [ ] Implementação de Upload de Arquivos (Fotos/Documentos)
- [ ] Integração com WhatsApp/SMS para Agendamentos


