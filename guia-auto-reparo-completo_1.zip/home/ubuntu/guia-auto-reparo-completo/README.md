# Guia Auto Reparo

Este é o repositório do projeto Guia Auto Reparo, um marketplace para agendamento de serviços automotivos, conectando usuários a oficinas confiáveis.

## Estrutura do Projeto

O projeto é dividido em três partes principais:

- **`backend/`**: Contém o servidor Node.js (Express) e a lógica de negócios, incluindo a API RESTful para comunicação com o frontend e o banco de dados.
- **`frontend/guia-auto-reparo-frontend/`**: Contém a aplicação web construída com React, responsável pela interface do usuário.
- **`backend/database/`**: Contém os scripts SQL para a criação do esquema do banco de dados e para a inserção de dados de exemplo.

## Tecnologias Utilizadas

### Frontend
- React 18 + Vite
- React Router DOM
- Tailwind CSS
- shadcn/ui (componentes de UI)
- Lucide React (ícones)

### Backend
- Node.js + Express
- MySQL2 (driver MySQL)
- CORS (Cross-Origin Resource Sharing)
- dotenv (para variáveis de ambiente)

### Banco de Dados
- MySQL

### Ferramentas
- ESLint (para linting de código)
- PNPM (gerenciador de pacotes)
- Git (controle de versão)
- Docker / Docker Compose (para conteinerização)

## Configuração e Execução (Local com Docker Compose)

Para configurar e executar o projeto localmente usando Docker Compose, siga os passos abaixo:

1.  **Pré-requisitos:**
    - Docker Desktop (ou Docker Engine e Docker Compose) instalado.

2.  **Variáveis de Ambiente:**
    - Crie um arquivo `.env` na raiz do diretório `backend/src/` com as seguintes variáveis:
        ```
        DB_HOST=db
        DB_USER=root
        DB_PASSWORD=password
        DB_NAME=guia_auto_reparo
        PORT=3000
        FRONTEND_URL=http://localhost:3001
        NODE_ENV=development
        ```
    - Crie um arquivo `.env` na raiz do diretório `frontend/guia-auto-reparo-frontend/` com a seguinte variável:
        ```
        VITE_API_URL=http://localhost:3000
        ```

3.  **Executar com Docker Compose:**
    - Navegue até a raiz do projeto (onde está o `docker-compose.yml`).
    - Execute o comando:
        ```bash
        docker-compose up --build
        ```
    - Este comando irá:
        - Construir as imagens Docker para o backend e frontend.
        - Criar e iniciar os contêineres para o banco de dados MySQL, backend e frontend.
        - Executar os scripts SQL (`schema_completo.sql` e `seed.sql`) no contêiner do MySQL para configurar o banco de dados e popular com dados de exemplo.

4.  **Acessar a Aplicação:**
    - O frontend estará disponível em `http://localhost:3001`.
    - O backend estará disponível em `http://localhost:3000/api`.

## Configuração e Execução (Local sem Docker Compose - Manual)

Se você preferir executar o projeto sem Docker Compose, siga estas instruções:

### Backend

1.  **Pré-requisitos:**
    - Node.js (versão 18 ou superior) e npm/pnpm instalados.
    - Servidor MySQL rodando localmente.

2.  **Configuração do Banco de Dados:**
    - Crie um banco de dados MySQL chamado `guia_auto_reparo`.
    - Execute o script `backend/database/schema_completo.sql` para criar as tabelas.
    - Opcional: Execute o script `backend/database/seed.sql` para popular o banco com dados de exemplo.

3.  **Instalação de Dependências:**
    - Navegue até o diretório `backend/`.
    - Instale as dependências:
        ```bash
        pnpm install
        ```

4.  **Variáveis de Ambiente:**
    - Crie um arquivo `.env` na raiz do diretório `backend/src/` com as seguintes variáveis (ajuste `DB_HOST`, `DB_USER`, `DB_PASSWORD` conforme sua configuração local do MySQL):
        ```
        DB_HOST=localhost
        DB_USER=root
        DB_PASSWORD=password
        DB_NAME=guia_auto_reparo
        PORT=3000
        FRONTEND_URL=http://localhost:3001
        NODE_ENV=development
        ```

5.  **Executar o Backend:**
    - No diretório `backend/`:
        ```bash
        pnpm start
        ```
    - O servidor estará rodando em `http://localhost:3000`.

### Frontend

1.  **Pré-requisitos:**
    - Node.js (versão 18 ou superior) e npm/pnpm instalados.

2.  **Instalação de Dependências:**
    - Navegue até o diretório `frontend/guia-auto-reparo-frontend/`.
    - Instale as dependências:
        ```bash
        pnpm install
        ```

3.  **Variáveis de Ambiente:**
    - Crie um arquivo `.env` na raiz do diretório `frontend/guia-auto-reparo-frontend/` com a seguinte variável:
        ```
        VITE_API_URL=http://localhost:3000
        ```

4.  **Executar o Frontend:**
    - No diretório `frontend/guia-auto-reparo-frontend/`:
        ```bash
        pnpm dev
        ```
    - A aplicação estará disponível em `http://localhost:3001`.

## Deploy em Produção

Para deploy em produção, considere as seguintes etapas:

1.  **Servidor:** Utilize um servidor de produção (VPS, AWS EC2, Google Cloud, etc.) com Node.js, MySQL e um servidor web (como Nginx ou Apache) instalados.
2.  **Banco de Dados:** Crie o banco de dados MySQL no seu servidor de produção e importe o `backend/database/schema_completo.sql`.
3.  **Variáveis de Ambiente:** Configure as variáveis de ambiente no seu servidor de produção para o backend e frontend. **Nunca exponha credenciais de banco de dados diretamente no frontend.**
4.  **Build do Frontend:** No seu ambiente de desenvolvimento, execute `pnpm build` no diretório `frontend/guia-auto-reparo-frontend/`. Isso criará uma pasta `dist` com os arquivos estáticos otimizados.
5.  **Deploy:** Copie os arquivos do backend e a pasta `dist` do frontend para o seu servidor de produção.
6.  **Process Manager:** Use um gerenciador de processos como PM2 para manter seu aplicativo Node.js rodando continuamente.
7.  **Servidor Web (Nginx/Apache):** Configure Nginx ou Apache para servir os arquivos estáticos do frontend e atuar como um proxy reverso para o seu backend Node.js.

## Contribuição

Sinta-se à vontade para contribuir com o projeto. Para isso, faça um fork do repositório, crie uma nova branch para suas alterações e envie um pull request.

## Licença

Este projeto está licenciado sob a licença ISC.


